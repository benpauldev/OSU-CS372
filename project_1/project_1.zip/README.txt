
CS 372
Project 1 
Author: Benjamin Fondell

******** Compile and execute host.py ********

$ chmod +x host.py

$ ./host.py <server port>

******** Compile and execute client.c ********

$ gcc -Wall client.c -o client

$ ./client <server ip> <server port>

******** How to use the program ********

Follow the prompts to create server and client usernames.

Intiate conversation by sending a message from the client.

Exchange messages alternately between client and server.
